import os
import time
import cv2
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import mss
import pydirectinput

# 1. 訓練資料集類別
class SkyVisionDataset(Dataset):
    def __init__(self, csv_file="game_dataset/labels.csv", img_dir="game_dataset/images"):
        self.csv_file = csv_file
        self.img_dir = img_dir
        
        if os.path.exists(self.csv_file):
            self.data = pd.read_csv(self.csv_file)
            self.actions = self.data['action'].unique()
            self.action_to_id = {act: i for i, act in enumerate(self.actions)}
        else:
            self.data = pd.DataFrame(columns=['filename', 'action'])
            self.actions = ["none", "move_w", "jump", "interact"]
            self.action_to_id = {act: i for i, act in enumerate(self.actions)}
        
    def __len__(self):
        return len(self.data)
        
    def __getitem__(self, idx):
        img_name = os.path.join(self.img_dir, self.data.iloc[idx, 0])
        image = cv2.imread(img_name, cv2.IMREAD_GRAYSCALE)
        if image is None:
            image = cv2.zeros((72, 128), dtype=np.uint8) # 預設空圖防錯
        image = image / 255.0 # 正規化
        image = torch.tensor(image, dtype=torch.float32).unsqueeze(0) # (1, 72, 128)
        
        action_str = self.data.iloc[idx, 1]
        label = self.action_to_id.get(action_str, 0)
        return image, torch.tensor(label, dtype=torch.long)

# 2. 輕量化 CNN 模型架構
class SkyCNN(nn.Module):
    def __init__(self, num_classes):
        super(SkyCNN, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2), # 36 x 64
            nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)  # 18 x 32
        )
        self.fc = nn.Sequential(
            nn.Linear(32 * 18 * 32, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes)
        )
        
    def forward(self, x):
        x = self.conv(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x

# 3. 訓練函數
def train_model(csv_path="game_dataset/labels.csv", img_dir="game_dataset/images", epochs=5):
    if not os.path.exists(csv_path):
        print(f"【錯誤】找不到訓練標籤檔: {csv_path}，請先收集畫面資料集！")
        return
        
    dataset = SkyVisionDataset(csv_path, img_dir)
    if len(dataset) == 0:
        print("【錯誤】資料集為空，無法進行訓練。")
        return
        
    dataloader = DataLoader(dataset, batch_size=32, shuffle=True)
    
    model = SkyCNN(num_classes=len(dataset.action_to_id))
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    print("開始訓練純影像 AI 模型...")
    for epoch in range(epochs):
        running_loss = 0.0
        for images, labels in dataloader:
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        print(f"Epoch {epoch+1}/{epochs}, Loss: {running_loss/len(dataloader):.4f}")
        
    os.makedirs("models", exist_ok=True)
    torch.save(model.state_dict(), "models/sky_vision_model.pth")
    print("模型訓練完成，已儲存至 models/sky_vision_model.pth")

# 4. AI 自動駕駛推理函數
def run_ai_autopilot():
    model_path = "models/sky_vision_model.pth"
    if not os.path.exists(model_path):
        print(f"找不到模型權重檔 {model_path}，請先執行 AI 模型訓練！")
        return
        
    actions_list = ["none", "move_w", "jump", "interact"]
    model = SkyCNN(num_classes=len(actions_list))
    model.load_state_dict(torch.load(model_path))
    model.eval()
    
    sct = mss.mss()
    monitor = {"top": 100, "left": 100, "width": 640, "height": 360}
    
    print("AI 自動駕駛已啟動，請切換至遊戲視窗。按 Ctrl+C 或關閉視窗可終止。")
    try:
        with torch.no_grad():
            while True:
                img = np.array(sct.grab(monitor))
                frame = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
                
                # 影像縮放與轉灰階
                resized = cv2.resize(frame, (128, 72))
                gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY) / 255.0
                tensor_img = torch.tensor(gray, dtype=torch.float32).unsqueeze(0).unsqueeze(0)
                
                outputs = model(tensor_img)
                _, predicted = torch.max(outputs.data, 1)
                action = actions_list[predicted.item()]
                
                print(f"AI 預測動作: {action}")
                
                if action == "move_w":
                    pydirectinput.press('w')
                elif action == "jump":
                    pydirectinput.press('space')
                elif action == "interact":
                    pydirectinput.press('f')
                    
                time.sleep(0.1)
    except KeyboardInterrupt:
        print("AI 自動駕駛已停止。")
