import time
import json
import os
from pynput import keyboard

class SkyRouteRecorder:
    def __init__(self, output_path="routes/cloud_route.json", map_name="雲野跑圖路線"):
        self.output_path = output_path
        self.map_name = map_name
        self.recorded_waypoints = []
        self.key_press_times = {}
        
        # 確保 routes 目錄存在
        os.makedirs(os.path.dirname(self.output_path), exist_ok=True)

    def _get_action_name(self, key):
        """解析按鍵並轉換為標準動作名稱"""
        try:
            key_char = key.char.lower() if hasattr(key, 'char') and key.char else str(key)
        except AttributeError:
            key_char = str(key)

        if 'space' in key_char:
            return 'jump'
        elif 'f' in key_char:
            return 'interact'
        elif key_char in ['w', 'a', 's', 'd']:
            return f"move_{key_char}"
        return None

    def on_press(self, key):
        """按下按鍵時記錄起始時間"""
        action_name = self._get_action_name(key)
        if action_name and action_name not in self.key_press_times:
            self.key_press_times[action_name] = time.time()

    def on_release(self, key):
        """放開按鍵時計算持續時間並寫入 waypoint"""
        action_name = self._get_action_name(key)
        
        # 偵測 ESC 鍵以停止錄製
        if key == keyboard.Key.esc:
            print("\n偵測到 ESC 鍵，正在停止錄製並存檔...")
            return False

        if not action_name:
            return

        if action_name in self.key_press_times:
            start_time = self.key_press_times.pop(action_name)
            duration = round(time.time() - start_time, 2)
            
            if duration > 0.05: # 過濾極短的誤觸
                waypoint = {
                    "action": action_name,
                    "duration": duration,
                    "landmark_img": None,
                    "desc": f"手動動作: {action_name} 持續 {duration} 秒"
                }
                self.recorded_waypoints.append(waypoint)
                print(f"已記錄: 動作={action_name}, 持續時間={duration}s")

    def start_recording(self):
        print("=== 光遇跑圖路徑錄製工具 ===")
        print("操作說明：")
        print("1. 切換至遊戲視窗並開始手動跑圖。")
        print("2. 系統將自動記錄 W, A, S, D, Space (跳躍), F (互動) 及其持續時間。")
        print("3. 跑完後按下鍵盤上的 [ESC] 鍵即可結束並自動存檔。\n")

        # 啟動鍵盤監聽器
        with keyboard.Listener(on_press=self.on_press, on_release=self.on_release) as listener:
            listener.join()

        # 組合輸出資料結構
        output_data = {
            "map_name": self.map_name,
            "waypoints": self.recorded_waypoints
        }

        # 寫入 JSON 檔案
        with open(self.output_path, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, ensure_ascii=False, indent=4)

        print(f"\n【成功】路線已儲存至 {self.output_path}！總共錄製了 {len(self.recorded_waypoints)} 個動作指令。")
