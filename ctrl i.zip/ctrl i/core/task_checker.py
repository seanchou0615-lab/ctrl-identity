import time
import cv2
import mss
import numpy as np
import easyocr

class SkyTaskChecker:
    _instance = None
    _reader = None

    def __new__(cls):
        # 單例模式：避免每次呼叫都重新載入模型，節省記憶體與初始化時間
        if cls._instance is None:
            cls._instance = super(SkyTaskChecker, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if SkyTaskChecker._reader is None:
            print("正在初始化高效能 OCR 模型（EasyOCR CPU 模式），請稍候...")
            SkyTaskChecker._reader = easyocr.Reader(['ch_tra', 'en'], gpu=False)
        self.sct = mss.mss()
        # 建議依你的遊戲解析度微調任務面板截圖區塊座標
        self.monitor = {"top": 120, "left": 950, "width": 300, "height": 250}

    def _preprocess(self, img):
        """強化版影像前處理：灰階 -> 放大 -> 雙邊過濾去噪 -> 局部二值化"""
        gray = cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY)
        resized = cv2.resize(gray, (0, 0), fx=2.5, fy=2.5, interpolation=cv2.INTER_CUBIC)
        filtered = cv2.bilateralFilter(resized, 9, 75, 75)
        _, thresh = cv2.threshold(filtered, 180, 255, cv2.THRESH_BINARY)
        return thresh

    def scan_tasks(self):
        img = np.array(self.sct.grab(self.monitor))
        processed_img = self._preprocess(img)
        cv2.imwrite("debug_task_optimized.png", processed_img)
        
        results = SkyTaskChecker._reader.readtext(processed_img)
        tasks_found = []
        for _, text, prob in results:
            if prob > 0.35:
                tasks_found.append(text)
        return tasks_found

    def check_task_status(self):
        tasks = self.scan_tasks()
        if not tasks:
            return "未偵測到任務內容，請確認任務面板是否正確開啟。"
        combined = "".join(tasks)
        if "已完成" in combined or "✓" in combined:
            return "狀態：每日任務已全數完成！"
        return f"狀態：辨識到未完成任務 -> {' | '.join(tasks)}"
