import tkinter as tk
from gui.app import SkyAssistantGUI

if __name__ == "__main__":
    root = tk.Tk()
    app = SkyAssistantGUI(root)
    root.mainloop()
