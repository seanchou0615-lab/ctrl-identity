# utils/navigator.py
import time
import os
import cv2
import numpy as np
import mss
import pydirectinput
import random

class SkyNavigator:
    def __init__(self):
        self.sct = mss.mss()
        self.MONITOR = {"top": 100, "left": 100, "width": 1280, "height": 720}

    def match_landmark(self, template_path, threshold=0.75, timeout=8.0):
        if not template_path or not os.path.exists(template_path):
            return True
            
        template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            return True

        print(f"正在尋找地標: {template_path} ...")
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            img = np.array(self.sct.grab(self.MONITOR))
            frame = cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY)
            
            result = cv2.matchTemplate(frame, template, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, _ = cv2.minMaxLoc(result)
            
            if max_val >= threshold:
                print(f"【地標對齊成功】相似度: {max_val:.2f}")
                return True
                
            time.sleep(0.3)
            
        print("【提示】地標對齊超時，繼續執行下一步驟。")
        return False

    def execute_waypoint_with_monitoring(self, wp):
        action = wp.get("action")
        duration = wp.get("duration", 1.0)
        landmark_img = wp.get("landmark_img")
        desc = wp.get("desc", "")
        
        print(f"\n執行動作: [{desc}] (類型: {action})")
        
        if "move" in action or action == "move_w":
            pydirectinput.keyDown('w')
            start_time = time.time()
            stuck_counter = 0
            last_gray = None
            
            while time.time() - start_time < duration:
                img = np.array(self.sct.grab(self.MONITOR))
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                
                if last_gray is not None:
                    diff = np.mean(cv2.absdiff(gray, last_gray))
                    if diff < 1.2:
                        stuck_counter += 1
                        if stuck_counter > 15:
                            print("【警告】偵測到角色卡牆，執行自動脫困程序...")
                            pydirectinput.keyUp('w')
                            escape_key = random.choice(['a', 'd'])
                            pydirectinput.keyDown(escape_key)
                            pydirectinput.press('space')
                            time.sleep(0.6)
                            pydirectinput.keyUp(escape_key)
                            pydirectinput.keyDown('w')
                            stuck_counter = 0
                    else:
                        stuck_counter = 0
                last_gray = gray.copy()
                time.sleep(0.1)
            pydirectinput.keyUp('w')
            
        elif action == "jump":
            pydirectinput.press('space')
            time.sleep(duration)
        elif action == "interact" or action == "f":
            pydirectinput.press('f')
            time.sleep(duration)
            
        if landmark_img:
            self.match_landmark(landmark_img)
