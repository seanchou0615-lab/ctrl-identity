# gui/app.py
import tkinter as tk
from tkinter import scrolledtext
import threading
import time
import os
import sys
import json
import pydirectinput

from core.task_checker import SkyTaskChecker
from core.route_recorder import SkyRouteRecorder
from core.vision_ai import run_ai_autopilot, train_model
from utils.navigator import SkyNavigator

class RedirectText:
    def __init__(self, text_widget):
        self.text_widget = text_widget
    def write(self, string):
        self.text_widget.after(0, self._insert, string)
    def _insert(self, string):
        self.text_widget.insert(tk.END, string)
        self.text_widget.see(tk.END)
    def flush(self):
        pass

class SkyAssistantGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Sky Assistant - 模組化控制面板")
        self.root.geometry("700x580")
        
        self.navigator = SkyNavigator()

        # 建立按鈕與介面排版
        title_label = tk.Label(root, text="✨ 光遇智慧輔助助手 (模組化架構) ✨", font=("Microsoft JhengHei", 14, "bold"))
        title_label.pack(pady=10)

        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=5, padx=20, fill=tk.X)

        self.create_button(btn_frame, "1. 執行自訂跑圖路線 (含防卡點)", self.start_run_route_thread, "#4CAF50")
        self.create_button(btn_frame, "2. OCR 每日任務辨識檢查", self.start_task_check_thread, "#2196F3")
        self.create_button(btn_frame, "3. 錄製新的跑圖路線", self.start_record_thread, "#FF9800")
        self.create_button(btn_frame, "4. 訓練純影像 AI 模型", self.start_train_thread, "#9C27B0")
        self.create_button(btn_frame, "5. 啟動 AI 自動駕駛", self.start_ai_thread, "#F44336")

        log_label = tk.Label(root, text="即時執行日誌：", font=("Microsoft JhengHei", 10, "bold"), anchor="w")
        log_label.pack(pady=(10, 2), padx=20, anchor="w")

        self.log_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, font=("Consolas", 10), bg="#1e1e1e", fg="#00ff00")
        self.log_area.pack(pady=5, padx=20, fill=tk.BOTH, expand=True)

        sys.stdout = RedirectText(self.log_area)
        print("【系統初始化】模組化系統就緒。\n")

    def create_button(self, parent, text, command, bg_color):
        btn = tk.Button(parent, text=text, font=("Microsoft JhengHei", 10, "bold"), 
                          bg=bg_color, fg="white", relief=tk.RAISED, cursor="hand2", command=command)
        btn.pack(side=tk.TOP, fill=tk.X, pady=3)

    def run_in_thread(self, target_func):
        thread = threading.Thread(target=target_func)
        thread.daemon = True
        thread.start()

    def start_task_check_thread(self):
        def task():
            print("\n--- 開始執行 OCR 每日任務檢查 ---")
            checker = SkyTaskChecker()
            print("請在 3 秒內切換至遊戲畫面並打開任務選單...")
            time.sleep(3.0)
            print(checker.check_task_status())
        self.run_in_thread(task)

    def start_run_route_thread(self):
        def task():
            route_path = "routes/cloud_route.json"
            if not os.path.exists(route_path):
                print(f"錯誤：找不到路線檔案 {route_path}")
                return
            with open(route_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                waypoints = data.get("waypoints", [])
            print(f"\n--- 準備執行地圖: {data.get('map_name')} ---")
            print("3 秒後開始執行，請迅速切換至遊戲視窗！")
            time.sleep(3.0)
            try:
                for wp in waypoints:
                    self.navigator.execute_waypoint_with_monitoring(wp)
                print("\n【完成】所有路線點已執行完畢！")
            except Exception as e:
                pydirectinput.keyUp('w')
                print(f"\n【錯誤】中斷: {e}")
        self.run_in_thread(task)

    def start_record_thread(self):
        def task():
            recorder = SkyRouteRecorder(output_path="routes/cloud_route.json", map_name="GUI錄製路線")
            recorder.start_recording()
        self.run_in_thread(task)

    def start_train_thread(self):
        def task():
            train_model()
        self.run_in_thread(task)

    def start_ai_thread(self):
        def task():
            run_ai_autopilot()
        self.run_in_thread(task)
